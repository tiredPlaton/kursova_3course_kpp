from flask import Flask, render_template, request, redirect, url_for, jsonify, session, flash
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
from functools import wraps
from flask import Flask, render_template, session, request
import random
from werkzeug.utils import send_from_directory

# Ініціалізація додатку
app = Flask(__name__)
app.config['SECRET_KEY'] = '0286eebe0c70b410d7e1796ec793d24ad630fa0c431b341cc537db9a3a0e9249'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///housing_complex.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'

# Ініціалізація бази даних
db = SQLAlchemy(app)
migrate = Migrate(app, db)


# Моделі бази даних
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    password = db.Column(db.String(200), nullable=False)
    apartment = db.Column(db.String(20), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    is_approved = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Відносини
    utility_bills = db.relationship('UtilityBill', backref='user', lazy=True)
    master_requests = db.relationship('MasterRequest', backref='user', lazy=True)


class UtilityBill(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    bill_type = db.Column(db.String(50), nullable=False)  # water, electricity, gas, etc.
    amount = db.Column(db.Float, nullable=False)
    period = db.Column(db.String(20), nullable=False)  # MM-YYYY
    is_paid = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class MasterRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, in_progress, completed
    response = db.Column(db.Text)
    preferred_time = db.Column(db.String(50))
    is_urgent = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)


class Announcement(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_pinned = db.Column(db.Boolean, default=False)


# Декоратори для контролю доступу
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)

    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if not user or not user.is_admin:
            flash('Доступ заборонено', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)

    return decorated_function


# Маршрути для фронтенду
@app.route('/')
def index():
    announcements = Announcement.query.order_by(Announcement.created_at.desc()).limit(3).all()
    return render_template('index.html', announcements=announcements)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False

        user = User.query.filter_by(email=email).first()

        if not user or not check_password_hash(user.password, password):
            flash('Невірний email або пароль', 'danger')
            return redirect(url_for('login'))

        if not user.is_approved:
            flash('Ваш акаунт ще не підтверджено адміністратором', 'warning')
            return redirect(url_for('login'))

        session['user_id'] = user.id
        session['is_admin'] = user.is_admin

        flash('Успішний вхід!', 'success')
        return redirect(url_for('dashboard'))

    return render_template('auth/login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form.get('fullName')
        email = request.form.get('email')
        phone = request.form.get('phone')
        password = request.form.get('password')
        apartment = request.form.get('apartmentNumber')

        # Перевірка чи існує користувач
        if User.query.filter_by(email=email).first():
            flash('Користувач з таким email вже існує', 'danger')
            return redirect(url_for('register'))

        # Створення нового користувача
        new_user = User(
            full_name=full_name,
            email=email,
            phone=phone,
            password=generate_password_hash(password, method='sha256'),
            apartment=apartment
        )

        db.session.add(new_user)
        db.session.commit()

        flash('Реєстрація успішна! Очікуйте підтвердження адміністратора', 'success')
        return redirect(url_for('login'))

    return render_template('auth/register.html')


@app.route('/dashboard')
@login_required
def dashboard():
    user = User.query.get(session['user_id'])
    utility_bills = UtilityBill.query.filter_by(user_id=user.id).order_by(UtilityBill.period.desc()).limit(4).all()
    master_requests = MasterRequest.query.filter_by(user_id=user.id).order_by(MasterRequest.created_at.desc()).limit(
        3).all()

    return render_template('user/dashboard.html',
                           user=user,
                           utility_bills=utility_bills,
                           master_requests=master_requests)


@app.route('/master', methods=['GET', 'POST'])
@login_required
def master_request():
    if request.method == 'POST':
        category = request.form.get('category')
        description = request.form.get('description')
        preferred_time = request.form.get('preferred-time')
        is_urgent = True if request.form.get('urgent') else False

        new_request = MasterRequest(
            user_id=session['user_id'],
            category=category,
            description=description,
            preferred_time=preferred_time,
            is_urgent=is_urgent
        )

        db.session.add(new_request)
        db.session.commit()

        flash('Заявку успішно відправлено!', 'success')
        return redirect(url_for('master_request'))

    requests = MasterRequest.query.filter_by(user_id=session['user_id']).order_by(MasterRequest.created_at.desc()).all()
    return render_template('user/master.html', requests=requests)


@app.route('/admin')
@admin_required
def admin_dashboard():
    total_users = User.query.count()
    pending_requests = MasterRequest.query.filter_by(status='pending').count()
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    recent_requests = MasterRequest.query.order_by(MasterRequest.created_at.desc()).limit(5).all()

    return render_template('admin.html',
                           total_users=total_users,
                           pending_requests=pending_requests,
                           recent_users=recent_users,
                           recent_requests=recent_requests)


# API для фронтенду
@app.route('/api/utility-bills', methods=['GET'])
@login_required
def get_utility_bills():
    bills = UtilityBill.query.filter_by(user_id=session['user_id']).all()
    return jsonify([{
        'id': bill.id,
        'type': bill.bill_type,
        'amount': bill.amount,
        'period': bill.period,
        'is_paid': bill.is_paid
    } for bill in bills])


@app.route('/api/pay-bill/<int:bill_id>', methods=['POST'])
@login_required
def pay_bill(bill_id):
    bill = UtilityBill.query.get(bill_id)
    if not bill or bill.user_id != session['user_id']:
        return jsonify({'success': False, 'message': 'Рахунок не знайдено'})

    bill.is_paid = True
    db.session.commit()

    return jsonify({'success': True, 'message': 'Рахунок оплачено'})


@app.route('/api/master-requests', methods=['GET', 'POST'])
@login_required
def handle_master_requests():
    if request.method == 'POST':
        data = request.get_json()
        new_request = MasterRequest(
            user_id=session['user_id'],
            category=data['category'],
            description=data['description'],
            preferred_time=data.get('preferredTime', 'any')
        )
        db.session.add(new_request)
        db.session.commit()

        return jsonify({
            'success': True,
            'request': {
                'id': new_request.id,
                'category': new_request.category,
                'description': new_request.description,
                'status': new_request.status,
                'created_at': new_request.created_at.strftime('%d.%m.%Y %H:%M')
            }
        })

    requests = MasterRequest.query.filter_by(user_id=session['user_id']).order_by(MasterRequest.created_at.desc()).all()
    return jsonify([{
        'id': req.id,
        'category': req.category,
        'description': req.description,
        'status': req.status,
        'response': req.response,
        'created_at': req.created_at.strftime('%d.%m.%Y')
    } for req in requests])


# Адмін API
@app.route('/api/admin/users', methods=['GET'])
@admin_required
def admin_get_users():
    users = User.query.all()
    return jsonify([{
        'id': user.id,
        'full_name': user.full_name,
        'email': user.email,
        'apartment': user.apartment,
        'is_approved': user.is_approved,
        'created_at': user.created_at.strftime('%d.%m.%Y')
    } for user in users])


@app.route('/api/admin/approve-user/<int:user_id>', methods=['POST'])
@admin_required
def admin_approve_user(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({'success': False, 'message': 'Користувача не знайдено'})

    user.is_approved = True
    db.session.commit()

    # Тут можна додати відправку email з підтвердженням

    return jsonify({'success': True, 'message': 'Користувача підтверджено'})


@app.route('/api/admin/master-requests', methods=['GET'])
@admin_required
def admin_get_requests():
    status = request.args.get('status', 'all')
    query = MasterRequest.query

    if status != 'all':
        query = query.filter_by(status=status)

    requests = query.order_by(MasterRequest.created_at.desc()).all()

    return jsonify([{
        'id': req.id,
        'user': req.user.full_name,
        'apartment': req.user.apartment,
        'category': req.category,
        'description': req.description,
        'status': req.status,
        'created_at': req.created_at.strftime('%d.%m.%Y %H:%M')
    } for req in requests])


@app.route('/api/admin/update-request/<int:request_id>', methods=['POST'])
@admin_required
def admin_update_request(request_id):
    data = request.get_json()
    req = MasterRequest.query.get(request_id)

    if not req:
        return jsonify({'success': False, 'message': 'Заявку не знайдено'})

    req.status = data.get('status', req.status)
    req.response = data.get('response', req.response)
    db.session.commit()

    return jsonify({'success': True, 'message': 'Заявку оновлено'})


# Допоміжні маршрути
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))


@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)


# Список сторінок у потрібному порядку
ERROR_PAGES = [
    'user/dashboard.html',
    'user/shop.html',
    'user/master.html',
    'admin.html'
]


@app.errorhandler(404)
def page_not_found(e):
    # Ініціалізуємо лічильник у сесії, якщо його немає
    if 'error_page_index' not in session:
        # Адміни починають з admin.html, інші - з dashboard.html
        session['error_page_index'] = 3 if session.get('is_admin') else 0

    # Обираємо поточну сторінку зі списку
    current_page = ERROR_PAGES[session['error_page_index']]

    # Збільшуємо лічильник (або скидаємо на 0, якщо досягли кінця списку)
    session['error_page_index'] = (session['error_page_index'] + 1) % len(ERROR_PAGES)

    return render_template(current_page), 404


@app.route('/reset_404_counter', methods=['POST'])
def reset_counter():
    session.pop('error_page_index', None)  # Видаляємо лічильник
    return '', 200


# Тестові маршрути для імітації ролей
@app.route('/set_admin')
def set_admin():
    session['is_admin'] = True
    return "Режим адміна увімкнено"


@app.route('/set_user')
def set_user():
    session['is_admin'] = False
    return "Режим звичайного користувача увімкнено"


# Тестовий маршрут для виклику 404
@app.route('/test_404')
def test_404():
    # Генеруємо випадковий неіснуючий URL для імітації 404
    non_existent_url = f'/non_existent_{random.randint(1, 1000)}'
    return f'<a href="{non_existent_url}">Натисніть для 404 помилки</a>'


if __name__ == '__main__':
    app.run(debug=True)

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500


# Запуск додатку
if __name__ == '__main__':
    with app.app_context():
        db.create_all()

        # Створення тестового адміна
        if not User.query.filter_by(email='admin@example.com').first():
            admin = User(
                full_name='Головний Адміністратор',
                email='admin@example.com',
                phone='+380991234567',
                password=generate_password_hash('admin123'),
                apartment='ADMIN',
                is_admin=True,
                is_approved=True
            )
            db.session.add(admin)

            # Тестові користувачі
            users = [
                User(
                    full_name='Іван Петренко',
                    email='user1@example.com',
                    phone='+380671234567',
                    password=generate_password_hash('password123'),
                    apartment='45-2',
                    is_approved=True
                ),
                User(
                    full_name='Марія Сидорова',
                    email='user2@example.com',
                    phone='+380931234567',
                    password=generate_password_hash('password123'),
                    apartment='12-1',
                    is_approved=True
                )
            ]
            db.session.add_all(users)

            # Тестові комунальні платежі
            bills = [
                UtilityBill(
                    user_id=2,
                    bill_type='water',
                    amount=450.50,
                    period='11-2023',
                    is_paid=False
                ),
                UtilityBill(
                    user_id=2,
                    bill_type='electricity',
                    amount=780.20,
                    period='11-2023',
                    is_paid=True
                )
            ]
            db.session.add_all(bills)

            # Тестові заявки майстрів
            requests = [
                MasterRequest(
                    user_id=2,
                    category='plumbing',
                    description='Протікання крана на кухні',
                    status='completed',
                    response='Виконано заміну прокладки 15.11.2023'
                ),
                MasterRequest(
                    user_id=3,
                    category='electricity',
                    description='Не працює розетка у вітальні',
                    status='in_progress'
                )
            ]
            db.session.add_all(requests)

            # Тестові оголошення
            announcements = [
                Announcement(
                    title='Профілактичні роботи у водопостачанні',
                    content='20 листопада з 9:00 до 17:00 будуть проводитись профілактичні роботи...',
                    is_pinned=True
                ),
                Announcement(
                    title='Новорічні прикраси комплексу',
                    content='Запрошуємо всіх бажаючих взяти участь у прикрашанні території...'
                )
            ]
            db.session.add_all(announcements)

            db.session.commit()

    app.run(debug=True)