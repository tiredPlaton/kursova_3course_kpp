/**
 * Головний модуль анімацій для ЖК "E-Devlet"
 * Версія 1.0
 */

class Animations {
  constructor() {
    // Ініціалізація
    this.initScrollAnimations();
    this.initHoverEffects();
    this.initInteractiveElements();
    this.setupObservers();
    this.addLoadEvents();
  }

  /**
   * Анімації при скролі
   */
  initScrollAnimations() {
    const animateOnScroll = () => {
      document.querySelectorAll('.news-card, .info-card').forEach(card => {
        const cardTop = card.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;

        if (cardTop < windowHeight * 0.85) {
          card.style.opacity = '1';
          card.style.transform = 'translateY(0)';
          card.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
        }
      });
    };

    // Дебаунс для оптимізації
    let isScrolling;
    window.addEventListener('scroll', () => {
      window.clearTimeout(isScrolling);
      isScrolling = setTimeout(() => {
        animateOnScroll();
      }, 60);
    }, { passive: true });

    // Ініціалізація при завантаженні
    animateOnScroll();
  }

  /**
   * Ефекти при наведенні
   */
  initHoverEffects() {
    // Для карток новин
    document.querySelectorAll('.news-card').forEach(card => {
      card.addEventListener('mouseenter', () => {
        card.style.boxShadow = '0 12px 25px rgba(0, 0, 0, 0.15)';
        card.querySelector('.news-icon').style.transform = 'rotate(15deg) scale(1.1)';
      });

      card.addEventListener('mouseleave', () => {
        card.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
        card.querySelector('.news-icon').style.transform = 'rotate(0) scale(1)';
      });
    });

    // Для навігаційних кнопок
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('mouseenter', () => {
        link.style.transform = 'translateY(-3px)';
        link.querySelector('i').style.transform = 'scale(1.2)';
      });

      link.addEventListener('mouseleave', () => {
        link.style.transform = 'translateY(0)';
        link.querySelector('i').style.transform = 'scale(1)';
      });
    });
  }

  /**
   * Інтерактивні елементи
   */
  initInteractiveElements() {
    // Розгортання деталей новин
    document.querySelectorAll('.news-card').forEach(card => {
      const details = card.querySelector('.news-details');
      const toggleButton = card.querySelector('.news-header');

      toggleButton.addEventListener('click', () => {
        details.classList.toggle('expanded');

        // Плавна анімація висоти
        if (details.classList.contains('expanded')) {
          details.style.maxHeight = `${details.scrollHeight}px`;
        } else {
          details.style.maxHeight = '0';
        }
      });
    });

    // Пульсація логотипу
    const logo = document.querySelector('.logo');
    if (logo) {
      setInterval(() => {
        logo.classList.toggle('pulse-active');
      }, 3000);
    }
  }

  /**
   * Intersection Observer для складних анімацій
   */
  setupObservers() {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -100px 0px'
    };

    const sectionObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animated');
        }
      });
    }, observerOptions);

    document.querySelectorAll('section').forEach(section => {
      sectionObserver.observe(section);
    });
  }

  /**
   * Події завантаження сторінки
   */
  addLoadEvents() {
    window.addEventListener('load', () => {
      // Анімація заголовка
      const logo = document.querySelector('.logo');
      if (logo) {
        setTimeout(() => {
          logo.classList.add('loaded');
        }, 500);
      }

      // Послідовне з'явлення елементів
      document.querySelectorAll('.news-card, .info-card').forEach((el, index) => {
        setTimeout(() => {
          el.style.opacity = '1';
          el.style.transform = 'translateY(0)';
        }, 100 * index);
      });
    });
  }

  /**
   * Додаткові утиліти
   */
  debounce(func, wait = 20, immediate = false) {
    let timeout;
    return function() {
      const context = this, args = arguments;
      const later = function() {
        timeout = null;
        if (!immediate) func.apply(context, args);
      };
      const callNow = immediate && !timeout;
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      if (callNow) func.apply(context, args);
    };
  }
}

// Ініціалізація при повному завантаженні DOM
document.addEventListener('DOMContentLoaded', () => {
  new Animations();
});

/**
 * Додаткові глобальні анімації
 */

// Плавний скрол для якорних посилань
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelector(this.getAttribute('href')).scrollIntoView({
      behavior: 'smooth'
    });
  });
});

// Анімація кнопок при кліку
document.querySelectorAll('button, .btn').forEach(button => {
  button.addEventListener('mousedown', () => {
    button.style.transform = 'scale(0.95)';
  });
  button.addEventListener('mouseup', () => {
    button.style.transform = 'scale(1)';
  });
  button.addEventListener('mouseleave', () => {
    button.style.transform = 'scale(1)';
  });
});