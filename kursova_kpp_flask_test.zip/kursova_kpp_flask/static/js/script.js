/**
 * Головний модуль додатку ЖК "E-Devlet"
 * Версія 1.0.0
 */

class HousingComplexApp {
  constructor() {
    this.apiBaseUrl = '/api';
    this.currentUser = null;
    this.initModules();
    this.setupEventListeners();
    this.checkAuthStatus();
  }

  // Ініціалізація модулів
  initModules() {
    this.authModule = new AuthModule(this);
    this.dashboardModule = new DashboardModule(this);
    this.masterModule = new MasterModule(this);
    this.paymentModule = new PaymentModule(this);
    this.notificationModule = new NotificationModule(this);
    this.uiModule = new UIModule();
  }

  // Налаштування глобальних слухачів подій
  setupEventListeners() {
    document.addEventListener('DOMContentLoaded', () => {
      this.uiModule.initAnimations();
      this.uiModule.setupFormValidations();
    });

    // Глобальний обробник помилок API
    document.addEventListener('apiError', (e) => {
      this.notificationModule.showError(e.detail.message);
    });
  }

  // Перевірка статусу авторизації
  async checkAuthStatus() {
    try {
      const response = await fetch(`${this.apiBaseUrl}/check-auth`, {
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        this.currentUser = data.user;
        document.dispatchEvent(new CustomEvent('authChange', { detail: { isAuthenticated: true } }));
      }
    } catch (error) {
      console.error('Auth check failed:', error);
    }
  }

  // Глобальний метод для API запитів
  async makeApiRequest(endpoint, method = 'GET', body = null) {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include'
    };

    if (body) {
      options.body = JSON.stringify(body);
    }

    try {
      const response = await fetch(`${this.apiBaseUrl}/${endpoint}`, options);

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'API request failed');
      }

      return await response.json();
    } catch (error) {
      document.dispatchEvent(new CustomEvent('apiError', { detail: { message: error.message } }));
      throw error;
    }
  }
}

// Модуль авторизації
class AuthModule {
  constructor(app) {
    this.app = app;
    this.setupAuthForms();
  }

  setupAuthForms() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registrationForm');

    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await this.handleLogin();
      });
    }

    if (registerForm) {
      registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        await this.handleRegistration();
      });
    }
  }

  async handleLogin() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('rememberMe').checked;

    try {
      const data = await this.app.makeApiRequest('login', 'POST', {
        email,
        password,
        rememberMe
      });

      this.app.currentUser = data.user;
      this.app.notificationModule.showSuccess('Вхід успішний!');
      setTimeout(() => window.location.href = '/dashboard', 1500);
    } catch (error) {
      this.app.notificationModule.showError(error.message);
    }
  }

  async handleRegistration() {
    const formData = {
      fullName: document.getElementById('fullName').value,
      email: document.getElementById('email').value,
      phone: document.getElementById('phone').value,
      password: document.getElementById('password').value,
      apartment: document.getElementById('apartmentNumber').value
    };

    try {
      await this.app.makeApiRequest('register', 'POST', formData);
      this.app.notificationModule.showSuccess('Реєстрація успішна! Очікуйте підтвердження.');
      setTimeout(() => window.location.href = '/login', 2000);
    } catch (error) {
      this.app.notificationModule.showError(error.message);
    }
  }
}

// Модуль особистого кабінету
class DashboardModule {
  constructor(app) {
    this.app = app;
    this.initDashboard();
  }

  async initDashboard() {
    if (!document.getElementById('dashboard')) return;

    try {
      const [bills, requests, announcements] = await Promise.all([
        this.app.makeApiRequest('utility-bills'),
        this.app.makeApiRequest('master-requests'),
        this.app.makeApiRequest('announcements')
      ]);

      this.renderUtilityBills(bills);
      this.renderMasterRequests(requests);
      this.renderAnnouncements(announcements);
    } catch (error) {
      console.error('Dashboard init error:', error);
    }
  }

  renderUtilityBills(bills) {
    const container = document.getElementById('utilityBillsContainer');
    if (!container) return;

    container.innerHTML = bills.map(bill => `
      <div class="dashboard-card" data-bill-id="${bill.id}">
        <div class="card-header">
          <h3><i class="fas fa-${this.getBillIcon(bill.type)}"></i> ${this.getBillTitle(bill.type)}</h3>
          <span class="badge ${bill.is_paid ? 'badge-success' : 'badge-warning'}">
            ${bill.is_paid ? 'Оплачено' : 'Очікує оплати'}
          </span>
        </div>
        <div class="card-body">
          <p>Сума: <strong>${bill.amount} ₴</strong></p>
          <p>Період: ${bill.period}</p>
          ${!bill.is_paid ? 
            `<button class="pay-btn" data-bill-id="${bill.id}">
              <i class="fas fa-wallet"></i> Оплатити
            </button>` : ''
          }
        </div>
      </div>
    `).join('');

    // Додаємо обробники кнопок оплати
    document.querySelectorAll('.pay-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const billId = e.currentTarget.dataset.billId;
        await this.app.paymentModule.handlePayment(billId);
      });
    });
  }

  getBillIcon(type) {
    const icons = {
      water: 'tint',
      electricity: 'bolt',
      gas: 'fire',
      trash: 'trash'
    };
    return icons[type] || 'file-invoice-dollar';
  }

  getBillTitle(type) {
    const titles = {
      water: 'Водопостачання',
      electricity: 'Електроенергія',
      gas: 'Газопостачання',
      trash: 'Вивіз сміття'
    };
    return titles[type] || type;
  }

  renderMasterRequests(requests) {
    const container = document.getElementById('masterRequestsContainer');
    if (!container) return;

    container.innerHTML = requests.map(request => `
      <div class="request-item" data-request-id="${request.id}">
        <div class="request-header">
          <span class="request-category">
            <i class="fas fa-${this.getRequestIcon(request.category)}"></i>
            ${this.getRequestCategory(request.category)}
          </span>
          <span class="request-date">${request.created_at}</span>
          <span class="status-badge status-${request.status}">
            ${this.getStatusText(request.status)}
          </span>
        </div>
        <p class="request-description">${request.description}</p>
        ${request.response ? `
          <div class="request-response">
            <p class="response-title">
              <i class="fas fa-info-circle"></i> Відповідь:
            </p>
            <p>${request.response}</p>
          </div>
        ` : ''}
      </div>
    `).join('');
  }

  getRequestIcon(category) {
    const icons = {
      plumbing: 'faucet',
      electricity: 'plug',
      heating: 'fire',
      'doors-windows': 'door-open',
      furniture: 'couch',
      other: 'tools'
    };
    return icons[category] || 'tools';
  }

  getRequestCategory(category) {
    const categories = {
      plumbing: 'Сантехніка',
      electricity: 'Електрика',
      heating: 'Опалення',
      'doors-windows': 'Двері/Вікна',
      furniture: 'Меблі',
      other: 'Інше'
    };
    return categories[category] || category;
  }

  getStatusText(status) {
    const statuses = {
      pending: 'Очікує',
      in_progress: 'В роботі',
      completed: 'Виконано'
    };
    return statuses[status] || status;
  }

  renderAnnouncements(announcements) {
    const container = document.getElementById('announcementsContainer');
    if (!container) return;

    container.innerHTML = announcements.map(announcement => `
      <div class="announcement-card">
        <h3 class="announcement-title">${announcement.title}</h3>
        <p class="announcement-date">${announcement.created_at}</p>
        <p class="announcement-text">${announcement.content}</p>
        ${announcement.is_pinned ? '<span class="pinned-badge"><i class="fas fa-thumbtack"></i> Закріплено</span>' : ''}
      </div>
    `).join('');
  }
}

// Модуль виклику майстрів
class MasterModule {
  constructor(app) {
    this.app = app;
    this.initMasterRequestForm();
  }

  initMasterRequestForm() {
    const form = document.getElementById('masterRequestForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      await this.handleMasterRequest();
    });

    // Ініціалізація історії заявок
    this.loadRequestHistory();
  }

  async handleMasterRequest() {
    const formData = {
      category: document.getElementById('category').value,
      description: document.getElementById('description').value,
      preferred_time: document.getElementById('preferred-time').value,
      is_urgent: document.getElementById('urgent').checked
    };

    try {
      const submitBtn = document.querySelector('#masterRequestForm button[type="submit"]');
      const originalText = submitBtn.innerHTML;

      submitBtn.disabled = true;
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Відправка...';

      const newRequest = await this.app.makeApiRequest('master-requests', 'POST', formData);

      this.app.notificationModule.showSuccess('Заявку успішно відправлено!');
      this.addRequestToHistory(newRequest.request);
      document.getElementById('masterRequestForm').reset();

      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
    } catch (error) {
      this.app.notificationModule.showError(error.message);
    }
  }

  async loadRequestHistory() {
    try {
      const data = await this.app.makeApiRequest('master-requests');
      this.renderRequestHistory(data);
    } catch (error) {
      console.error('Failed to load request history:', error);
    }
  }

  renderRequestHistory(requests) {
    const container = document.getElementById('requestsList');
    if (!container) return;

    container.innerHTML = requests.map((request, index) => `
      <div class="request-item" style="animation-delay: ${index * 0.1}s">
        <div class="request-header">
          <span class="request-category">
            <i class="fas fa-${this.getRequestIcon(request.category)}"></i>
            ${this.getRequestCategory(request.category)}
          </span>
          <span class="request-date">${request.created_at}</span>
          <span class="request-status status-${request.status}">
            ${this.getStatusText(request.status)}
          </span>
        </div>
        <p class="request-description">${request.description}</p>
        ${request.response ? `
          <div class="request-response">
            <p class="response-title">
              <i class="fas fa-info-circle"></i> Відповідь:
            </p>
            <p>${request.response}</p>
          </div>
        ` : ''}
      </div>
    `).join('');
  }

  addRequestToHistory(request) {
    const container = document.getElementById('requestsList');
    if (!container) return;

    const newItem = document.createElement('div');
    newItem.className = 'request-item';
    newItem.style.animationDelay = '0s';
    newItem.innerHTML = `
      <div class="request-header">
        <span class="request-category">
          <i class="fas fa-${this.getRequestIcon(request.category)}"></i>
          ${this.getRequestCategory(request.category)}
        </span>
        <span class="request-date">${new Date().toLocaleDateString()}</span>
        <span class="request-status status-pending">Очікує</span>
      </div>
      <p class="request-description">${request.description}</p>
    `;

    container.insertBefore(newItem, container.firstChild);
  }

  getRequestIcon(category) {
    // ... (такий же метод як у DashboardModule)
  }

  getRequestCategory(category) {
    // ... (такий же метод як у DashboardModule)
  }

  getStatusText(status) {
    // ... (такий же метод як у DashboardModule)
  }
}

// Модуль оплати
class PaymentModule {
  constructor(app) {
    this.app = app;
  }

  async handlePayment(billId) {
    try {
      const payBtn = document.querySelector(`.pay-btn[data-bill-id="${billId}"]`);
      const originalText = payBtn.innerHTML;

      payBtn.disabled = true;
      payBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Обробка...';

      await this.app.makeApiRequest(`pay-bill/${billId}`, 'POST');

      payBtn.innerHTML = '<i class="fas fa-check"></i> Оплачено';
      payBtn.style.backgroundColor = '#28a745';

      setTimeout(() => {
        const card = payBtn.closest('.dashboard-card');
        card.querySelector('.badge').className = 'badge badge-success';
        card.querySelector('.badge').textContent = 'Оплачено';
        payBtn.remove();
      }, 2000);

      this.app.notificationModule.showSuccess('Оплата успішна!');
    } catch (error) {
      if (payBtn) {
        payBtn.innerHTML = originalText;
        payBtn.disabled = false;
      }
      this.app.notificationModule.showError(error.message);
    }
  }
}

// Модуль сповіщень
class NotificationModule {
  constructor() {
    this.notificationContainer = document.createElement('div');
    this.notificationContainer.className = 'notification-container';
    document.body.appendChild(this.notificationContainer);
  }

  showSuccess(message) {
    this.showNotification(message, 'success');
  }

  showError(message) {
    this.showNotification(message, 'error');
  }

  showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
      <div class="notification-icon">
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
      </div>
      <div class="notification-content">${message}</div>
      <button class="notification-close">&times;</button>
    `;

    this.notificationContainer.appendChild(notification);

    // Автоматичне закриття через 5 секунд
    setTimeout(() => {
      notification.classList.add('fade-out');
      setTimeout(() => notification.remove(), 300);
    }, 5000);

    // Закриття по кліку
    notification.querySelector('.notification-close').addEventListener('click', () => {
      notification.classList.add('fade-out');
      setTimeout(() => notification.remove(), 300);
    });
  }
}

// Модуль UI ефектів
class UIModule {
  initAnimations() {
    // Анімація при скролі
    const animateOnScroll = () => {
      document.querySelectorAll('.animate-on-scroll').forEach(el => {
        const rect = el.getBoundingClientRect();
        const isVisible = rect.top < window.innerHeight * 0.8;

        if (isVisible) {
          el.classList.add('animated');
        }
      });
    };

    window.addEventListener('scroll', () => {
      animateOnScroll();
    });

    animateOnScroll();

    // Ініціалізація тултипів
    this.initTooltips();

    // Ініціалізація модальних вікон
    this.initModals();
  }

  initTooltips() {
    document.querySelectorAll('[data-tooltip]').forEach(el => {
      const tooltip = document.createElement('div');
      tooltip.className = 'tooltip';
      tooltip.textContent = el.dataset.tooltip;
      document.body.appendChild(tooltip);

      el.addEventListener('mouseenter', (e) => {
        const rect = e.target.getBoundingClientRect();
        tooltip.style.left = `${rect.left + rect.width / 2 - tooltip.offsetWidth / 2}px`;
        tooltip.style.top = `${rect.top - tooltip.offsetHeight - 10}px`;
        tooltip.classList.add('visible');
      });

      el.addEventListener('mouseleave', () => {
        tooltip.classList.remove('visible');
      });
    });
  }

  initModals() {
    document.querySelectorAll('[data-modal-target]').forEach(trigger => {
      const modalId = trigger.dataset.modalTarget;
      const modal = document.getElementById(modalId);

      if (modal) {
        trigger.addEventListener('click', () => {
          modal.classList.add('active');
          document.body.style.overflow = 'hidden';
        });

        modal.querySelectorAll('.modal-close, .modal-overlay').forEach(closeBtn => {
          closeBtn.addEventListener('click', () => {
            modal.classList.remove('active');
            document.body.style.overflow = '';
          });
        });
      }
    });
  }

  setupFormValidations() {
    document.querySelectorAll('form[data-validate]').forEach(form => {
      form.addEventListener('submit', function(e) {
        let isValid = true;

        form.querySelectorAll('[required]').forEach(input => {
          if (!input.value.trim()) {
            isValid = false;
            input.classList.add('is-invalid');
            const errorMsg = input.nextElementSibling?.classList.contains('invalid-feedback')
              ? input.nextElementSibling
              : document.createElement('div');

            errorMsg.className = 'invalid-feedback';
            errorMsg.textContent = 'Це поле обов\'язкове';
            input.insertAdjacentElement('afterend', errorMsg);
          }
        });

        if (!isValid) {
          e.preventDefault();
          form.querySelector('.is-invalid').focus();
        }
      });

      // Валідація при втраті фокусу
      form.querySelectorAll('input, select, textarea').forEach(input => {
        input.addEventListener('blur', () => {
          if (input.required && !input.value.trim()) {
            input.classList.add('is-invalid');
          } else {
            input.classList.remove('is-invalid');
          }
        });
      });
    });

    // Спеціальна валідація для пароля
    const passwordInput = document.getElementById('password');
    if (passwordInput) {
      passwordInput.addEventListener('input', this.validatePasswordStrength);
    }

    // Підтвердження пароля
    const confirmPassword = document.getElementById('confirmPassword');
    if (confirmPassword) {
      confirmPassword.addEventListener('input', this.validatePasswordMatch);
    }
  }

  validatePasswordStrength(e) {
    const password = e.target.value;
    const strengthBar = document.getElementById('passwordStrength');
    const strengthLabel = document.getElementById('strengthLabel');

    if (!strengthBar || !strengthLabel) return;

    let strength = 0;
    if (password.length >= 8) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;

    const width = (strength / 4) * 100;
    strengthBar.style.width = `${width}%`;

    const colors = ['#ff4444', '#ffbb33', '#00C851', '#00C851'];
    const labels = ['Слабкий', 'Середній', 'Сильний', 'Дуже сильний'];

    strengthBar.style.backgroundColor = colors[strength];
    strengthLabel.textContent = labels[strength];
    strengthLabel.style.color = colors[strength];
  }

  validatePasswordMatch(e) {
    const password = document.getElementById('password')?.value;
    const confirmPassword = e.target.value;
    const feedback = e.target.nextElementSibling?.classList.contains('invalid-feedback')
      ? e.target.nextElementSibling
      : null;

    if (!password || !feedback) return;

    if (confirmPassword && password !== confirmPassword) {
      e.target.classList.add('is-invalid');
      feedback.style.display = 'block';
    } else {
      e.target.classList.remove('is-invalid');
      feedback.style.display = 'none';
    }
  }
}

// Ініціалізація додатку
document.addEventListener('DOMContentLoaded', () => {
  const app = new HousingComplexApp();
  window.app = app; // Для доступу з консолі (debug)
});